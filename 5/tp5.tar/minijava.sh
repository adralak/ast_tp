#!/bin/sh

java -cp minijava.jar:. mj.tools.MiniJavaInterpreter < $1
