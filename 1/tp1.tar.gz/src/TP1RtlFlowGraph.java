import rtl.graph.FlowGraph;
import rtl.*;

import java.util.Set;

public class TP1RtlFlowGraph extends FlowGraph {
	
	public Node entry() {
		return null; //TODO
	}
	
	public Object instr(Node n) {
		return null; //TODO
	}

	public TP1RtlFlowGraph(Function f) {
		 //TODO
	}

	public Set<Ident> def(Node node) {
		return null; //TODO
	}

	public Set<Ident> use(Node node) {
		return null; //TODO
	}

	public Node node(Instr i) {
		return null; //TODO
	}

	public Node node(EndInstr i) {
		return null; //TODO
	}

}
